# Attribution Interpretation Report

## Executive Summary

### Single Most Important Behavioural Insight:
The `Meta / paid_social` channel is highly dynamic in terms of attribution, shifting significantly between models. This suggests that this channel plays a critical role both in the early stages of customer journeys and as a high-converting touchpoint later on.

### Biggest Attribution Risk:
The `Direct / (none)` channel shows significant ambiguity and variability across models, making it challenging to draw firm conclusions about its true impact. Over-crediting or under-valuing this channel could lead to suboptimal marketing strategies.

### Most Important Strategic Takeaway:
Attribution models should be used as strategic lenses rather than absolute truths. Businesses must adopt a multi-model approach to gain a comprehensive understanding of their customer journey and optimise marketing efforts accordingly.

## Channel Role Analysis

### Meta / paid_social
- **Model Spread: $7,077.48**
  - **First-touch revenue:** $13,664.88
  - **Last-touch revenue:** $6,587.40
  - **Linear revenue:** $8,963.64
  - **Position-based revenue:** $9,823.89
  - **Time-decay revenue:** $7,643.10

The `Meta / paid_social` channel is highly sensitive to the attribution model used. The strong first-touch and weak last-touch values indicate that this channel drives significant discovery and initial interest but also provides substantial conversion late in the journey. This suggests a mix of demand generation and direct conversion roles.

### Google Ads / cpc
- **Model Spread: $3,810.19**
  - **First-touch revenue:** $7,107.66
  - **Last-touch revenue:** $10,917.85
  - **Linear revenue:** $9,843.84
  - **Position-based revenue:** $9,226.34
  - **Time-decay revenue:** $10,521.37

This channel shows a more consistent role across models but is predominantly conversion-oriented late in the journey, as indicated by the strong last-touch and linear values.

### Direct / (none)
- **Model Spread: $1,159.87**
  - **First-touch revenue:** $6,296.44
  - **Last-touch revenue:** $7,456.31
  - **Linear revenue:** $7,102.49
  - **Position-based revenue:** $6,934.59
  - **Time-decay revenue:** $7,321.16

The `Direct / (none)` channel shows stability but is undervalued by the first-touch model and overvalued in last-touch models. This suggests that while it plays a significant role, its impact is more consistent throughout the journey rather than being a single touchpoint.

### Organic / organic
- **Model Spread: $1,623.18**
  - **First-touch revenue:** $376.96
  - **Last-touch revenue:** $2,000.14
  - **Linear revenue:** $1,227.76
  - **Position-based revenue:** $1,201.63
  - **Time-decay revenue:** $1,552.43

This channel is less critical overall but important for conversion capture late in the journey.

### Unknown / (not set)
- **Model Spread: $484.24**
  - **First-touch revenue:** $907.61
  - **Last-touch revenue:** $1,391.85
  - **Linear revenue:** $1,215.72
  - **Position-based revenue:** $1,167.11
  - **Time-decay revenue:** $1,315.49

This channel is relatively stable but appears to capture some conversion late in the journey.

## Attribution Sensitivity Analysis

### Which Channels Shift Most Between Models:
- `Meta / paid_social` and `Google Ads / cpc` show significant shifts across models.
- The `Direct / (none)` and `Unknown / (not set)` channels are relatively stable but still exhibit variability.

### What This Implies Behaviorally:
The high sensitivity of the `Meta / paid_social` channel indicates that it is critical for both early discovery and late conversion. Marketers should invest in this channel to capture a broader range of customer interactions, not just direct conversions. Conversely, `Google Ads / cpc` shows consistent conversion-driven behavior but could be overvalued if only last-touch models are considered.

### Why Attribution Philosophy Changes the Marketing Story:
Different attribution models provide different insights into how customers interact with marketing channels. For instance, first-touch models highlight initial discovery, while last-touch models focus on final conversions. By using multiple models, marketers can gain a more nuanced understanding of customer journeys and optimize their strategies accordingly.

## Strategic Risks

### Relying Too Heavily on Last-click:
Last-click models undervalue demand generation channels like `Meta / paid_social`, which play significant roles in initial discovery and nurturing leads. Over-reliance on last-click metrics could lead to missed opportunities in early-stage marketing activities.

### Over-crediting Direct:
The ambiguity of the `Direct / (none)` channel suggests that over-crediting direct traffic might be misleading. Businesses should invest more in understanding why customers are using this method and how they can improve tracking quality.

### Weak Identity Stitching:
Weak identity stitching, particularly for channels like `Unknown / (not set)`, leads to uncertainty about true conversion attribution. Strengthening backend tracking and identity resolution is crucial for accurate attribution.

### Interpreting Attribution as Causality:
Attribution models do not prove causation; they only measure correlation. Treating them as such can lead to flawed marketing decisions, such as reducing budget for channels that are overvalued by certain models but are actually critical in the customer journey.

### Evaluating Channels Using Only One Attribution Philosophy:
Single-model approaches provide a narrow view of channel performance and fail to capture the complexity of customer journeys. Businesses should use multiple attribution models to gain a holistic understanding of their marketing effectiveness.

## Recommended Next Investigations

1. **Path Analysis**: Identify typical paths customers take from initial discovery to conversion.
2. **Sessionisation**: Analyze session behaviour to understand how users engage with different channels and touchpoints.
3. **Event Weighting**: Assign weights to events (e.g., ad clicks, page views) based on their impact on the customer journey.
4. **Incrementality Testing**: Measure the incremental impact of marketing activities.
5. **Probabilistic Attribution**: Use probabilistic models to account for uncertainty in attribution.
6. **Marketing Mix Modeling (MMM)**: Evaluate the overall effectiveness of different channels and allocate budgets optimally.
7. **Channel Grouping Refinement**: Re-evaluate channel groupings based on their role in customer journeys.
8. **Backend Identity Strengthening**: Improve tracking quality by refining backend identity resolution.
9. **Direct Traffic Decomposition**: Analyze direct traffic to understand its sources and optimize accordingly.

## Final Key Takeaway

Attribution models should be interpreted with caution, recognizing that they provide insights but do not prove causality. A multi-model approach is essential for understanding the full customer journey and optimizing marketing strategies effectively. Businesses must invest in tracking quality, identity stitching, and path analysis to make informed decisions based on comprehensive data.

By adopting a nuanced view of attribution, companies can better allocate resources and enhance their overall marketing performance.